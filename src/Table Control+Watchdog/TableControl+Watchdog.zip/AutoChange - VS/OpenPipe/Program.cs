﻿using System;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Threading;
using System.Reflection;

namespace ConsoleApplication1
{
    class Program
    {

        static NamedPipeClientStream client = new NamedPipeClientStream(".", @"HmiRuntime", PipeDirection.InOut, PipeOptions.Asynchronous);

        static StreamReader reader = new StreamReader(client);
        static StreamWriter writer = new StreamWriter(client);
        static FileSystemWatcher watcher = new FileSystemWatcher();
        
        static void Main(string[] args)
        {

            string path = args[0]; //@"C:\Users\Public";


            //Client
            
            client.Connect();
            Console.WriteLine("Connecting...");
            
            writer.WriteLine("ReadTagValue isFileChanged\n");
            writer.Flush();
            Console.WriteLine("Observing...");
            Console.WriteLine(reader.ReadLine());
            
            MonitorDirectory(path);

            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();
            
        }

        private static void MonitorDirectory(string path)
        {
            
            watcher.Path = path;
            watcher.NotifyFilter = NotifyFilters.Attributes
                    | NotifyFilters.CreationTime
                    | NotifyFilters.DirectoryName
                    | NotifyFilters.FileName
                    | NotifyFilters.LastAccess
                    | NotifyFilters.LastWrite
                    | NotifyFilters.Security
                    | NotifyFilters.Size;

            watcher.IncludeSubdirectories = false;
            watcher.Filter = "*.csv";
            watcher.Changed += OnChanged;
            watcher.Deleted += OnDeleted;
            watcher.EnableRaisingEvents = true;
        }

        
        private static void OnChanged(object sender, FileSystemEventArgs e)
        {
            try
            {
                watcher.EnableRaisingEvents = false;
                if (e.ChangeType != WatcherChangeTypes.Changed)
                {
                    return;
                }
                Console.WriteLine($"Changed: {e.FullPath}");

                writer.WriteLine("WriteTagValue isFileChanged 1\n");
                writer.Flush();
            }
            finally 
            {
                watcher.EnableRaisingEvents = true;
            }
                
                
            
            

        }
        private static void OnDeleted(object sender, FileSystemEventArgs e) =>
            Console.WriteLine($"Deleted: {e.FullPath}");

        private static void WriteTag(StreamWriter writer)
        {
            var WriteTag = "{\"Message\":\"WriteTag\",\"Params\":{\"Tags\":[{ \"Name\":\"isFileChanged\",\"Value\":\"true\"}]},\"ClientCookie\":\"myRequest2\"}";
            writer.WriteLine(WriteTag);

        }
        private static void StartSubscription(StreamWriter writer)
        {
            var Subscribe = "{\"Message\":\"SubscribeTag\",\"Params\":{\"Tags\":[\"Tag_0\",\"Tag_1\"]},\"ClientCookie\":\"mySubscription1\"}";
            writer.WriteLine(Subscribe);
        }

        private static void StopSubscription(StreamWriter writer)
        {
            var Unsubscribecommand = "{\"Message\":\"UnsubscribeTag\",\"ClientCookie\":\"mySubscription1\"}";
            writer.WriteLine(Unsubscribecommand);
        }

    }
}
